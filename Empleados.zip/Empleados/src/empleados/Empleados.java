/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empleados;

import java.util.Scanner;

/**
 *
 * @author meryw
 */
public class Empleados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Empleado e1=new Empleado(20,"12345678","Raul",3000);
        Empleado e2=new Empleado(30,"12345689","Erick",3000);
        System.out.println(e1);
        System.out.println(e2);
        
        System.out.println("Codigo");
        int codigo=Integer.parseInt(sc.nextLine());
        System.out.println("DNI");
        String dni=sc.nextLine();
        System.out.println("Nombre");
        String nombre=sc.nextLine();
        System.out.println("Sueldo");
        double sueldo=Double.parseDouble(sc.nextLine());
        
        Empleado e=new Empleado(codigo,dni,nombre,sueldo);
        System.out.println(e);
        
        Empleado[] empleados=new Empleado[2];
        for (int i=0;i<empleados.length;i++)
        {
            System.out.println("Codigo");
            int codigo1=Integer.parseInt(sc.nextLine());
            System.out.println("DNI");
            String dni1=sc.nextLine();
            System.out.println("Nombre");
            String nombre1=sc.nextLine();
            System.out.println("Sueldo");
            double sueldo1=Double.parseDouble(sc.nextLine());
            
            empleados[i]=new Empleado(codigo1,dni1,nombre1,sueldo1);
        }
        
        /*for (int i=0;i<empleados.length;i++)
        {
            System.out.println(empleados[i]);
        }*/
        double totalSueldo=0;
        double totalAFP=0;
        
        for (Empleado el:empleados){
            System.out.println(el);
            totalSueldo+=el.getSalario();
            totalAFP+=el.getAFP();
        }
        
        System.out.println(totalSueldo);
        
    }
    
}
