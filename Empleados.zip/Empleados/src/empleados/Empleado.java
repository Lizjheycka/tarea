/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empleados;

/**
 *
 * @author meryw
 */
public class Empleado {
    private int codigo;
    private String dni; 
    private String nombres;
    private double salario;
    public static final double PORCENTAJE_AFP=0.11;
    
    public Empleado(int codigo,String dni,
            String nombres,double salario ){
        this.codigo=codigo;
        this.dni=dni;
        this.nombres=nombres;
        this.salario=salario;
    }
    
    public double getSalario(){
        return this.salario;
    }
    
    public double getAFP(){
        return this.salario*PORCENTAJE_AFP;
    }
    
    @Override
    public String toString(){
        return "Codigo: " + this.codigo +
                " Nombres: " + this.nombres +
                " salario: " + this.salario;
    }
    
}
